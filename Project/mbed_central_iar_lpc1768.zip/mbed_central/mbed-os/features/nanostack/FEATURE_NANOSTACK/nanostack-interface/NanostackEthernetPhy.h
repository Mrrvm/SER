/*
 * Copyright (c) 2016 ARM Limited. All rights reserved.
 */

#ifndef NANOSTACK_ETHERNET_PHY_H_
#define NANOSTACK_ETHERNET_PHY_H_

#include "NanostackPhy.h"

class NanostackEthernetPhy : public NanostackPhy {
};

#endif /* NANOSTACK_INTERFACE_H_ */
