#include "mbed.h"
#include "LM75B.h"
#include <stdio.h>

CAN can2(MBED_CONF_APP_CAN2_RD, MBED_CONF_APP_CAN2_TD);

int main() {
    LM75B sensor(p28,p27);
    Serial pc(USBTX,USBRX);
    float temp;
    char msg[8];
    
    if (sensor.open()) {
        printf("Device detected!\n");
 
   
        while (1) {
            temp = (float)sensor.temp();
            printf("Iwdws %.3f\n", temp);
            sprintf(msg, "%.3f", temp);
            printf("%s", msg);
            can2.write(CANMessage(1500, msg, sizeof(msg)));
            wait(5.0);
        }
 
    } else {
        error("Device not detected!\n");
    }
}

