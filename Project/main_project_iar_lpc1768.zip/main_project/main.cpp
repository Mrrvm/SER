#include "mbed.h"
#include "codes.h"
#include "ultrasonic.h"

//
// SEE THIS:
// https://os.mbed.com/questions/73257/Canbus-data-sending-and-reading-problems/
//


CAN can1(MBED_CONF_APP_CAN1_RD, MBED_CONF_APP_CAN1_TD); // front of the car
CAN can2(MBED_CONF_APP_CAN2_RD, MBED_CONF_APP_CAN2_TD); // back of the car

ultrasonic muFront(MU_FRONT_TRIGGER, MU_FRONT_ECHO, .1, 1, &frontDistanceSensor); //Set the trigger pin to p6 and the echo pin to p7
                                                         //have updates every .1 seconds and a timeout after 1
                                                         //second, and call dist when the distance changes
                                                    
ultrasonic muBack(MU_BACK_TRIGGER, MU_BACK_ECHO, .1, 1, &backDistanceSensor);


/* : ===== END RECEIVING PART ===== : */


/* = START HANDLERS SECTION = */

/**
    temperature handler

    @param temp temperature received
*/
void temperatureHandler(int temp) {
    // TODO
}


/**
    LDR handler

    @param lum luminosity received
*/
void LDRHandler(int lum) {
    // TODO   
}


/**
    front distance handler

    @param dist distance received
*/
void frontDistanceHandler(int dist) {
    // TODO
}


/**
    front distance handler

    @param dist distance received
*/
void backDistanceHandler(int distance) {
    // TODO
}


/**
    front distance handler

    @param dist distance received
*/
void weightHandler(int weight) {
    // TODO
}


/**
    code error handler

    @param msg message received
*/
void codeNotFoundHandler(CANMessage msg) {
    printf("[error] CAN message received\r\n");
    printf("  ID      = 0x%.3x\r\n", msg.id);
    printf("  Type    = %d\r\n", msg.type);
    printf("  Format  = %d\r\n", msg.format);
    printf("  Length  = %d\r\n", msg.len);
    printf("  Data    =");            
    for(int i = 0; i < msg.len; i++)
        printf(" %.2x", msg.data[i]);
    printf("End Message\r\n");
}

/* = END HANDLERS SECTION = */


/**
    generic controller to handle messages received in the CAN BUS

    @param message message received
*/
void canController(CANMessage msg) {

    switch(msg.id) {
        // TEMPERATURE SENSOR
        case CODE_TEMPERATURE:
            temperatureHandler(*reinterpret_cast<int*>(msg.data));
            break;
        
        // FRONT DISTANCE SENSOR
        case CODE_LDR:
            LDRHandler(*reinterpret_cast<int*>(msg.data));
            break;

        // BACK DISTANCE SENSOR
        case CODE_FRONT_DISTANCE:
            frontDistanceHandler(*reinterpret_cast<int*>(msg.data));
            break;
            
        // BACK DISTANCE SENSOR
        case CODE_BACK_DISTANCE:
            backDistanceHandler(*reinterpret_cast<int*>(msg.data));
            break;
            
        // WEIGHT SENSOR
        case CODE_WEIGHT:
            weightHandler(*reinterpret_cast<int*>(msg.data));
            break;
                
        default:
            codeNotFoundHandler(msg);
    }

}


/**
    generic function to receive messages through the CAN BUS

    @param can CAN interface to communicate
*/
void receive(CAN can) {
    CANMessage msg;
    if(can.read(msg)) {
        canController(msg);
    }
}

/* : ===== END RECEIVING PART ===== : */


/* : ===== START SENDING PART ===== : */

/**
    generic function to send messages through the CAN BUS

    @param can CAN interface to communicate
    @param id code of the message
    @param message message to be sent
    @return 1 if message sent, 0 otherwise
*/
int send(CAN can, uint16_t id, char* message) {
    if(!can.write(CANMessage(id, reinterpret_cast<char*>(&message), sizeof(message)))) {
        printf("Error sending message %x %s", id, message);
        return 0;
        // TODO if something is wrong tell the other nodes that something is wrong?
    }
    return 1;
}


/**
    get current temperature from sensor

    @return int with temperature value
*/
int temperatureSensor() {
    
    
}


/**
    get current weight from sensor

    @return int with weight value
*/
int weightSensor() {
    
}


/**
    get current luminosity from sensor

    @return int with luminosity value
*/
int LDRSensor() {
    
}


/**
    get current front distance from sensor

    @return int with distance value in mm
*/
int frontDistanceSensor(int dist) {
    send(can1, CODE_FRONT_DISTANCE, dist);
}


/**
    get current back distance from sensor

    @return int with distance value in mm
*/
int backDistanceSensor(int dist) {
    
}


/**
    this is where the class checks if dist needs to be called
*/
void checkDistances() {
    muFront.checkDistance();
    muBack.checkDistance();
}


/* : ===== END SENDING PART ===== : */


/**
    function to setup environment variables, can bus, ...

    @param radius The radius of the circle.
    @return The volume of the sphere.
*/
void setup() {    
    can1.frequency(FREQUENCY);
    can2.frequency(FREQUENCY);
    
}


int main() {
    
    setup();
    
    while(1) {
        receive(can1);
        receive(can2); 
        wait(0.2);
        checkDistances(); // TODO check where to put this
    }
}
