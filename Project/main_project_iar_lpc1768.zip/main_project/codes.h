#ifndef CODES_H
#define CODES_H

#define FREQUENCY 250000

#define MU_FRONT_TRIGGER p6 // change me
#define MU_FRONT_ECHO p7 // change me
#define MU_BACK_TRIGGER p6 // change me
#define MU_BACK_ECHO p7 // change me


const uint16_t  CODE_TEMPERATURE = 0x200;       // Messages for temperature sensor
const uint16_t  CODE_LDR = 0x202;               // Messages for LDR sensor
const uint16_t  CODE_FRONT_DISTANCE = 0x203;    // Messages for front distance sensor
const uint16_t  CODE_BACK_DISTANCE = 0x204;     // Messages for back distance sensor
const uint16_t  CODE_WEIGHT = 0x205;            // Messages for weight sensor




#endif